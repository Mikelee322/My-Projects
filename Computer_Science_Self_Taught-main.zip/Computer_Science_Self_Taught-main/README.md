# Python for everybody
This respository captures my personal solutions to the Scientific Computing with Python Certification projects.

* Arithmetic Formatter
* Time Calculator
* Budget App
